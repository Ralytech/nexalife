import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ PROPERTY ROUTES ============
  properties: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserProperties(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const property = await db.getPropertyById(input.id);
        if (!property || property.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return property;
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          type: z.enum(["house", "apartment", "car", "land", "commercial"]),
          city: z.string().min(1),
          address: z.string().min(1),
          description: z.string().optional(),
          photos: z.array(z.string()).optional(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await db.createProperty({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          photos: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const property = await db.getPropertyById(input.id);
        if (!property || property.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.updateProperty(input.id, input);
      }),
  }),

  // ============ SERVICE ROUTES ============
  services: router({
    list: publicProcedure.query(async () => {
      return await db.getAllServices();
    }),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getServiceById(input.id);
      }),
  }),

  // ============ ORDER ROUTES ============
  orders: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserOrders(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order || order.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return order;
      }),

    create: protectedProcedure
      .input(
        z.object({
          propertyId: z.number(),
          serviceId: z.number(),
          scheduledDate: z.date().optional(),
          notes: z.string().optional(),
          specialRequests: z.string().optional(),
          price: z.number().positive(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Verify property ownership
        const property = await db.getPropertyById(input.propertyId);
        if (!property || property.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        return await db.createOrder({
          userId: ctx.user.id,
          propertyId: input.propertyId,
          serviceId: input.serviceId,
          scheduledDate: input.scheduledDate,
          notes: input.notes,
          specialRequests: input.specialRequests,
          price: input.price,
        });
      }),

    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order || order.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        return await db.updateOrderStatus(input.id, input.status);
      }),
  }),

  // ============ GROCERY ROUTES ============
  groceryBaskets: router({
    list: publicProcedure.query(async () => {
      return await db.getAllGroceryBaskets();
    }),
  }),

  groceryOrders: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserGroceryOrders(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          basketId: z.number(),
          propertyId: z.number(),
          deliveryDate: z.date(),
          deliveryNotes: z.string().optional(),
          customItems: z.array(z.any()).optional(),
          price: z.number().positive(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Verify property ownership
        const property = await db.getPropertyById(input.propertyId);
        if (!property || property.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        return await db.createGroceryOrder({
          userId: ctx.user.id,
          basketId: input.basketId,
          propertyId: input.propertyId,
          deliveryDate: input.deliveryDate,
          deliveryNotes: input.deliveryNotes,
          customItems: input.customItems,
          price: input.price,
        });
      }),
  }),

  // ============ REPORT ROUTES ============
  reports: router({
    get: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        return await db.getOrderReports(input.orderId);
      }),
  }),

  // ============ PAYMENT ROUTES ============
  payments: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserPayments(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          orderId: z.number().optional(),
          amount: z.number().positive(),
          currency: z.string().optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await db.createPayment({
          userId: ctx.user.id,
          orderId: input.orderId,
          amount: input.amount,
          currency: input.currency,
          description: input.description,
        });
      }),
  }),

  // ============ NOTIFICATION ROUTES ============
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }))
      .query(async ({ input, ctx }) => {
        return await db.getUserNotifications(ctx.user.id, input.unreadOnly);
      }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.markNotificationAsRead(input.id);
      }),
  }),

  // ============ PROFILE ROUTES ============
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserById(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          name: z.string().optional(),
          phone: z.string().optional(),
          country: z.string().optional(),
          language: z.enum(["en", "fr", "ht"]).optional(),
          bio: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Update user profile
        return { success: true };
      }),
  }),

  // ============ PROVIDER ROUTES ============
  provider: router({
    profile: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "provider" && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getProviderProfile(ctx.user.id);
    }),

    createProfile: protectedProcedure
      .input(
        z.object({
          specializations: z.array(z.string()).optional(),
          serviceArea: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "provider" && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.createProviderProfile({
          userId: ctx.user.id,
          ...input,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
