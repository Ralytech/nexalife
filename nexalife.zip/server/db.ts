import { eq, and, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  properties,
  orders,
  services,
  groceryOrders,
  groceryBaskets,
  reports,
  payments,
  notifications,
  emailPreferences,
  providerProfiles,
  reviews,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER OPERATIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone", "country"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ PROPERTY OPERATIONS ============

export async function createProperty(data: {
  userId: number;
  name: string;
  type: string;
  city: string;
  address: string;
  description?: string;
  photos?: any[];
  latitude?: string;
  longitude?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(properties).values({
    userId: data.userId,
    name: data.name,
    type: data.type as any,
    city: data.city,
    address: data.address,
    description: data.description,
    photos: data.photos,
    latitude: data.latitude as any,
    longitude: data.longitude as any,
  });

  return result;
}

export async function getUserProperties(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(properties)
    .where(and(eq(properties.userId, userId), eq(properties.status, "active")))
    .orderBy(desc(properties.createdAt));
}

export async function getPropertyById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(properties).where(eq(properties.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateProperty(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(properties).set(data).where(eq(properties.id, id));
}

// ============ SERVICE OPERATIONS ============

export async function getAllServices() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(services).where(eq(services.active, true));
}

export async function getServiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createService(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(services).values(data);
}

// ============ ORDER OPERATIONS ============

export async function createOrder(data: {
  userId: number;
  propertyId: number;
  serviceId: number;
  scheduledDate?: Date;
  notes?: string;
  specialRequests?: string;
  price: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(orders).values({
    userId: data.userId,
    propertyId: data.propertyId,
    serviceId: data.serviceId,
    scheduledDate: data.scheduledDate,
    notes: data.notes,
    specialRequests: data.specialRequests,
    price: data.price as any,
    status: "pending",
    paymentStatus: "pending",
  });

  return result;
}

export async function getUserOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateOrderStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(orders).set({ status: status as any }).where(eq(orders.id, id));
}

export async function updateOrderPaymentStatus(id: number, status: string, stripePaymentIntentId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const data: any = { paymentStatus: status };
  if (stripePaymentIntentId) {
    data.stripePaymentIntentId = stripePaymentIntentId;
  }

  return await db.update(orders).set(data).where(eq(orders.id, id));
}

// ============ GROCERY OPERATIONS ============

export async function getAllGroceryBaskets() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(groceryBaskets).where(eq(groceryBaskets.active, true));
}

export async function createGroceryOrder(data: {
  userId: number;
  basketId: number;
  propertyId: number;
  deliveryDate: Date;
  deliveryNotes?: string;
  customItems?: any[];
  price: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(groceryOrders).values({
    userId: data.userId,
    basketId: data.basketId,
    propertyId: data.propertyId,
    deliveryDate: data.deliveryDate,
    deliveryNotes: data.deliveryNotes,
    customItems: data.customItems,
    price: data.price as any,
    status: "pending",
    paymentStatus: "pending",
  });
}

export async function getUserGroceryOrders(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(groceryOrders)
    .where(eq(groceryOrders.userId, userId))
    .orderBy(desc(groceryOrders.createdAt));
}

// ============ REPORT OPERATIONS ============

export async function createReport(data: {
  orderId: number;
  providerId: number;
  photos?: any[];
  notes?: string;
  checklist?: any[];
  videoUrl?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(reports).values({
    orderId: data.orderId,
    providerId: data.providerId,
    photos: data.photos,
    notes: data.notes,
    checklist: data.checklist,
    videoUrl: data.videoUrl,
  });
}

export async function getOrderReports(orderId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(reports).where(eq(reports.orderId, orderId));
}

// ============ PAYMENT OPERATIONS ============

export async function createPayment(data: {
  userId: number;
  orderId?: number;
  amount: number;
  currency?: string;
  stripePaymentIntentId?: string;
  description?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(payments).values({
    userId: data.userId,
    orderId: data.orderId,
    amount: data.amount as any,
    currency: data.currency || "USD",
    stripePaymentIntentId: data.stripePaymentIntentId,
    description: data.description,
    status: "pending",
  });
}

export async function getUserPayments(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(payments)
    .where(eq(payments.userId, userId))
    .orderBy(desc(payments.createdAt));
}

export async function updatePaymentStatus(id: number, status: string, stripeChargeId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const data: any = { status };
  if (stripeChargeId) {
    data.stripeChargeId = stripeChargeId;
  }

  return await db.update(payments).set(data).where(eq(payments.id, id));
}

// ============ NOTIFICATION OPERATIONS ============

export async function createNotification(data: {
  userId: number;
  type: string;
  title: string;
  message: string;
  relatedOrderId?: number;
  relatedReportId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(notifications).values({
    userId: data.userId,
    type: data.type as any,
    title: data.title,
    message: data.message,
    relatedOrderId: data.relatedOrderId,
    relatedReportId: data.relatedReportId,
    read: false,
  });
}

export async function getUserNotifications(userId: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];

  if (unreadOnly) {
    return await db
      .select()
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.read, false)))
      .orderBy(desc(notifications.createdAt));
  }

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
}

// ============ EMAIL PREFERENCES ============

export async function getEmailPreferences(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(emailPreferences)
    .where(eq(emailPreferences.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createEmailPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(emailPreferences).values({
    userId,
    orderUpdates: true,
    photoUploads: true,
    serviceCompletions: true,
    paymentAlerts: true,
    weeklyDigest: true,
  });
}

// ============ PROVIDER OPERATIONS ============

export async function getProviderProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(providerProfiles)
    .where(eq(providerProfiles.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createProviderProfile(data: {
  userId: number;
  specializations?: any[];
  serviceArea?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(providerProfiles).values({
    userId: data.userId,
    specializations: data.specializations,
    serviceArea: data.serviceArea,
    verified: false,
  });
}

// ============ REVIEW OPERATIONS ============

export async function createReview(data: {
  orderId: number;
  userId: number;
  providerId: number;
  rating: number;
  comment?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(reviews).values({
    orderId: data.orderId,
    userId: data.userId,
    providerId: data.providerId,
    rating: data.rating,
    comment: data.comment,
  });
}

export async function getProviderReviews(providerId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(reviews)
    .where(eq(reviews.providerId, providerId))
    .orderBy(desc(reviews.createdAt));
}
