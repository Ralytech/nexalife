import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  json,
  datetime,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow and multi-role support.
 * Supports both diaspora clients and service providers.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  country: varchar("country", { length: 100 }),
  role: mysqlEnum("role", ["user", "provider", "admin"]).default("user").notNull(),
  profilePhoto: text("profilePhoto"), // S3 URL
  bio: text("bio"),
  language: mysqlEnum("language", ["en", "fr", "ht"]).default("en").notNull(),
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Properties owned by diaspora users in Haiti.
 * Stores property details and metadata for service ordering.
 */
export const properties = mysqlTable("properties", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["house", "apartment", "car", "land", "commercial"]).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  address: text("address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  description: text("description"),
  photos: json("photos"), // Array of S3 URLs
  yearBuilt: int("yearBuilt"),
  squareFootage: int("squareFootage"),
  bedrooms: int("bedrooms"),
  bathrooms: int("bathrooms"),
  status: mysqlEnum("status", ["active", "inactive", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Property = typeof properties.$inferSelect;
export type InsertProperty = typeof properties.$inferInsert;

/**
 * Available services offered on the platform.
 * Predefined service types with pricing and descriptions.
 */
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  category: mysqlEnum("category", ["inspection", "maintenance", "cleaning", "repairs", "grocery"]).notNull(),
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }).notNull(),
  estimatedDuration: int("estimatedDuration"), // in minutes
  icon: text("icon"), // S3 URL or emoji
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

/**
 * Service orders placed by diaspora users.
 * Tracks all service requests with status and pricing.
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  propertyId: int("propertyId").notNull(),
  serviceId: int("serviceId").notNull(),
  providerId: int("providerId"), // Assigned service provider
  status: mysqlEnum("status", ["pending", "accepted", "in_progress", "completed", "cancelled"]).default("pending").notNull(),
  scheduledDate: datetime("scheduledDate"),
  completedDate: datetime("completedDate"),
  notes: text("notes"),
  specialRequests: text("specialRequests"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "refunded"]).default("pending").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Grocery delivery baskets with predefined items.
 * Supports customization and delivery scheduling.
 */
export const groceryBaskets = mysqlTable("groceryBaskets", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  basePrice: decimal("basePrice", { precision: 10, scale: 2 }).notNull(),
  items: json("items"), // Array of {name, quantity, unit}
  image: text("image"), // S3 URL
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GroceryBasket = typeof groceryBaskets.$inferSelect;
export type InsertGroceryBasket = typeof groceryBaskets.$inferInsert;

/**
 * Grocery orders placed by diaspora users.
 * Tracks basket selections and delivery details.
 */
export const groceryOrders = mysqlTable("groceryOrders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  basketId: int("basketId").notNull(),
  propertyId: int("propertyId").notNull(),
  customItems: json("customItems"), // Additional items beyond basket
  deliveryDate: datetime("deliveryDate").notNull(),
  deliveryNotes: text("deliveryNotes"),
  status: mysqlEnum("status", ["pending", "confirmed", "in_delivery", "delivered", "cancelled"]).default("pending").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "paid", "refunded"]).default("pending").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GroceryOrder = typeof groceryOrders.$inferSelect;
export type InsertGroceryOrder = typeof groceryOrders.$inferInsert;

/**
 * Photo reports uploaded by service providers.
 * Stores photos, notes, and inspection checklists for completed services.
 */
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  providerId: int("providerId").notNull(),
  photos: json("photos"), // Array of {url, caption, timestamp}
  notes: text("notes"),
  checklist: json("checklist"), // Array of {item, completed, notes}
  videoUrl: text("videoUrl"), // S3 URL
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;

/**
 * Payment transactions for orders and services.
 * Tracks Stripe payment details and transaction history.
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  orderId: int("orderId"), // Can be service order or grocery order
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  status: mysqlEnum("status", ["pending", "succeeded", "failed", "refunded"]).default("pending").notNull(),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }).unique(),
  stripeChargeId: varchar("stripeChargeId", { length: 255 }),
  description: text("description"),
  metadata: json("metadata"), // Additional payment info
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Notifications for order updates and service completions.
 * Tracks user notifications with read status.
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["order_update", "photo_uploaded", "service_completed", "payment_received", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  relatedOrderId: int("relatedOrderId"),
  relatedReportId: int("relatedReportId"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Email alert preferences for users.
 * Allows users to customize notification settings.
 */
export const emailPreferences = mysqlTable("emailPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  orderUpdates: boolean("orderUpdates").default(true).notNull(),
  photoUploads: boolean("photoUploads").default(true).notNull(),
  serviceCompletions: boolean("serviceCompletions").default(true).notNull(),
  paymentAlerts: boolean("paymentAlerts").default(true).notNull(),
  weeklyDigest: boolean("weeklyDigest").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EmailPreferences = typeof emailPreferences.$inferSelect;
export type InsertEmailPreferences = typeof emailPreferences.$inferInsert;

/**
 * Provider profiles with ratings and specializations.
 * Extended information for service providers.
 */
export const providerProfiles = mysqlTable("providerProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  specializations: json("specializations"), // Array of service categories
  rating: decimal("rating", { precision: 3, scale: 2 }).default("5.00"),
  totalReviews: int("totalReviews").default(0),
  totalOrders: int("totalOrders").default(0),
  responseTime: int("responseTime"), // in minutes
  serviceArea: text("serviceArea"), // Cities/regions served
  bankAccount: varchar("bankAccount", { length: 255 }), // For payouts
  verified: boolean("verified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProviderProfile = typeof providerProfiles.$inferSelect;
export type InsertProviderProfile = typeof providerProfiles.$inferInsert;

/**
 * Reviews and ratings for service providers.
 * Tracks client feedback on completed services.
 */
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  userId: int("userId").notNull(),
  providerId: int("providerId").notNull(),
  rating: int("rating").notNull(), // 1-5
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

/**
 * Audit log for tracking platform activities.
 * Logs important actions for compliance and debugging.
 */
export const auditLog = mysqlTable("auditLog", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  action: varchar("action", { length: 255 }).notNull(),
  entityType: varchar("entityType", { length: 100 }),
  entityId: int("entityId"),
  changes: json("changes"),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLog.$inferSelect;
export type InsertAuditLog = typeof auditLog.$inferInsert;
