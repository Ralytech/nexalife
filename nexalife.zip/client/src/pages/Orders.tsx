import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Clock, CheckCircle2, AlertCircle, Loader, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, ReactNode } from "react";

export default function Orders() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [autoRefresh, setAutoRefresh] = useState(true);

  const { data: orders, isLoading, refetch } = trpc.orders.list.useQuery(undefined, {
    enabled: !!user,
  });

  // Auto-refresh orders every 5 seconds for real-time updates
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      refetch();
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefresh, refetch]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-5 h-5 text-warning" />;
      case "accepted":
        return <AlertCircle className="w-5 h-5 text-info" />;
      case "in_progress":
        return <Loader className="w-5 h-5 text-accent animate-spin" />;
      case "completed":
        return <CheckCircle2 className="w-5 h-5 text-success" />;
      case "cancelled":
        return <AlertCircle className="w-5 h-5 text-destructive" />;
      default:
        return <Clock className="w-5 h-5 text-muted" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "badge-warning";
      case "accepted":
        return "badge-primary";
      case "in_progress":
        return "badge-primary";
      case "completed":
        return "badge-success";
      case "cancelled":
        return "badge-error";
      default:
        return "badge-primary";
    }
  };

  const getStatusLabel = (status: string) => {
    return status
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const groupedOrders = {
    active: orders?.filter((o) => ["pending", "accepted", "in_progress"].includes(o.status)) || [],
    completed: orders?.filter((o) => o.status === "completed") || [],
    cancelled: orders?.filter((o) => o.status === "cancelled") || [],
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 hover:bg-muted/20 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-muted" />
            </button>
            <div>
              <h1 className="text-2xl font-bold">Service Orders</h1>
              <p className="text-sm text-muted">Track your service requests in real-time</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                autoRefresh
                  ? "bg-accent text-accent-foreground"
                  : "bg-muted/20 text-foreground hover:bg-muted/30"
              }`}
            >
              {autoRefresh ? "Auto-refresh ON" : "Auto-refresh OFF"}
            </button>

            <Button
              onClick={() => navigate("/services")}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Order
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-24 bg-muted/20 rounded"></div>
              </Card>
            ))}
          </div>
        ) : orders && orders.length > 0 ? (
          <div className="space-y-8">
            {/* Active Orders */}
            {groupedOrders.active.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Loader className="w-5 h-5 text-accent animate-spin" />
                  Active Orders ({groupedOrders.active.length})
                </h2>
                <div className="space-y-4">
                  {groupedOrders.active.map((order) => (
                    <OrderCard key={order.id} order={order} getStatusIcon={getStatusIcon} getStatusColor={getStatusColor} getStatusLabel={getStatusLabel} />
                  ))}
                </div>
              </div>
            )}

            {/* Completed Orders */}
            {groupedOrders.completed.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-success" />
                  Completed Orders ({groupedOrders.completed.length})
                </h2>
                <div className="space-y-4">
                  {groupedOrders.completed.map((order) => (
                    <OrderCard key={order.id} order={order} getStatusIcon={getStatusIcon} getStatusColor={getStatusColor} getStatusLabel={getStatusLabel} />
                  ))}
                </div>
              </div>
            )}

            {/* Cancelled Orders */}
            {groupedOrders.cancelled.length > 0 && (
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-destructive" />
                  Cancelled Orders ({groupedOrders.cancelled.length})
                </h2>
                <div className="space-y-4">
                  {groupedOrders.cancelled.map((order) => (
                    <OrderCard key={order.id} order={order} getStatusIcon={getStatusIcon} getStatusColor={getStatusColor} getStatusLabel={getStatusLabel} />
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Clock className="w-12 h-12 text-muted/30 mx-auto mb-4" />
            <p className="text-muted mb-4">No service orders yet</p>
            <Button
              onClick={() => navigate("/services")}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              Browse Services
            </Button>
          </Card>
        )}
      </main>
    </div>
  );
}

interface OrderCardProps {
  order: any;
  getStatusIcon: (status: string) => ReactNode;
  getStatusColor: (status: string) => string;
  getStatusLabel: (status: string) => string;
}

function OrderCard({ order, getStatusIcon, getStatusColor, getStatusLabel }: OrderCardProps) {
  const [, navigate] = useLocation();

  return (
    <Card className="p-6 hover:shadow-elevated transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold mb-1">Order #{order.id}</h3>
          <p className="text-sm text-muted">
            {new Date(order.createdAt).toLocaleDateString()} at{" "}
            {new Date(order.createdAt).toLocaleTimeString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {getStatusIcon(order.status)}
          <span className={`badge ${getStatusColor(order.status)} text-xs capitalize`}>
            {getStatusLabel(order.status)}
          </span>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4 mb-4 pb-4 border-b border-border">
        <div>
          <p className="text-xs text-muted mb-1">Service</p>
          <p className="font-semibold">Service #{order.serviceId}</p>
        </div>
        <div>
          <p className="text-xs text-muted mb-1">Property</p>
          <p className="font-semibold">Property #{order.propertyId}</p>
        </div>
        <div>
          <p className="text-xs text-muted mb-1">Scheduled</p>
          <p className="font-semibold">
            {order.scheduledDate ? new Date(order.scheduledDate).toLocaleDateString() : "Not scheduled"}
          </p>
        </div>
        <div>
          <p className="text-xs text-muted mb-1">Cost</p>
          <p className="font-semibold text-accent">${order.price}</p>
        </div>
      </div>

      {order.notes && (
        <div className="mb-4 pb-4 border-b border-border">
          <p className="text-xs text-muted mb-1">Notes</p>
          <p className="text-sm text-foreground">{order.notes}</p>
        </div>
      )}

      <div className="flex gap-2">
        <Button
          onClick={() => navigate(`/orders/${order.id}`)}
          variant="outline"
          className="flex-1 border-2 border-accent text-accent hover:bg-accent/10"
        >
          View Details
        </Button>
        {order.status === "completed" && (
          <Button className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90">
            View Report
          </Button>
        )}
      </div>
    </Card>
  );
}
