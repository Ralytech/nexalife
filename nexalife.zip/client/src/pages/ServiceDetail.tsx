import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, Calendar, Clock, MapPin, FileText, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function ServiceDetail() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/services/:id");
  const serviceId = params?.id ? parseInt(params.id) : null;

  const [selectedProperty, setSelectedProperty] = useState<number | null>(null);
  const [scheduledDate, setScheduledDate] = useState("");
  const [notes, setNotes] = useState("");
  const [specialRequests, setSpecialRequests] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: service, isLoading: serviceLoading } = trpc.services.get.useQuery(
    { id: serviceId || 0 },
    { enabled: !!serviceId }
  );

  const { data: properties } = trpc.properties.list.useQuery(undefined, { enabled: !!user });

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: (result) => {
      toast.success("Service order created successfully!");
      navigate("/orders");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create order");
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  if (!match || !serviceId) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <Card className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <p className="text-muted mb-4">Service not found</p>
            <Button onClick={() => navigate("/services")} className="bg-accent text-accent-foreground">
              Back to Services
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedProperty) {
      toast.error("Please select a property");
      return;
    }

    if (!scheduledDate) {
      toast.error("Please select a date and time");
      return;
    }

    setIsSubmitting(true);

    try {
      await createOrderMutation.mutateAsync({
        propertyId: selectedProperty,
        serviceId: serviceId,
        scheduledDate: new Date(scheduledDate),
        notes,
        specialRequests,
        price: parseFloat(String(service?.basePrice || 0)),
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const serviceIcons: Record<string, string> = {
    inspection: "🔍",
    maintenance: "🔧",
    cleaning: "🧹",
    repairs: "🛠️",
    grocery: "🛒",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => navigate("/services")}
            className="p-2 hover:bg-muted/20 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-muted" />
          </button>
          <h1 className="text-2xl font-bold">Request Service</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Service Details */}
          <div className="lg:col-span-1">
            {serviceLoading ? (
              <Card className="p-6 animate-pulse">
                <div className="h-24 bg-muted/20 rounded mb-4"></div>
                <div className="h-4 bg-muted/20 rounded mb-2"></div>
                <div className="h-4 bg-muted/20 rounded w-2/3"></div>
              </Card>
            ) : service ? (
              <Card className="p-6 sticky top-24">
                {/* Icon */}
                <div className="text-6xl mb-4">{serviceIcons[service.category] || "⚙️"}</div>

                {/* Title */}
                <h2 className="text-2xl font-bold mb-2">{service.name}</h2>
                <p className="text-sm text-muted mb-6 capitalize">{service.category}</p>

                {/* Description */}
                <div className="mb-6 pb-6 border-b border-border">
                  <p className="text-foreground">{service.description}</p>
                </div>

                {/* Details */}
                <div className="space-y-4">
                  {service.basePrice && (
                    <div className="flex items-center justify-between">
                      <span className="text-muted">Base Price</span>
                      <span className="text-2xl font-bold text-accent">${service.basePrice}</span>
                    </div>
                  )}

                  {service.estimatedDuration && (
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-accent" />
                      <div>
                        <p className="text-sm text-muted">Estimated Duration</p>
                        <p className="font-semibold">
                          {Math.round(service.estimatedDuration / 60)} hours
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-accent" />
                    <div>
                      <p className="text-sm text-muted">Service Type</p>
                      <p className="font-semibold capitalize">{service.category}</p>
                    </div>
                  </div>
                </div>
              </Card>
            ) : null}
          </div>

          {/* Order Form */}
          <div className="lg:col-span-2">
            <Card className="p-8">
              <h3 className="text-xl font-bold mb-6">Create Order</h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Property Selection */}
                <div>
                  <label className="block text-sm font-semibold mb-3">Select Property *</label>
                  {properties && properties.length > 0 ? (
                    <div className="space-y-2">
                      {properties.map((property) => (
                        <button
                          key={property.id}
                          type="button"
                          onClick={() => setSelectedProperty(property.id)}
                          className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                            selectedProperty === property.id
                              ? "border-accent bg-accent/10"
                              : "border-border hover:border-accent/50"
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <p className="font-semibold">{property.name}</p>
                              <p className="text-sm text-muted">
                                {property.address}, {property.city}
                              </p>
                            </div>
                            <span className="text-xs capitalize px-2 py-1 rounded bg-muted/20">
                              {property.type}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <Card className="p-4 bg-muted/10 border-0">
                      <p className="text-sm text-muted mb-3">No properties found</p>
                      <Button
                        type="button"
                        onClick={() => navigate("/properties/new")}
                        className="bg-accent text-accent-foreground hover:bg-accent/90"
                      >
                        Add Property
                      </Button>
                    </Card>
                  )}
                </div>

                {/* Date and Time Selection */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Preferred Date & Time *
                  </label>
                  <input
                    type="datetime-local"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    min={new Date().toISOString().slice(0, 16)}
                    className="input-base w-full"
                    required
                  />
                  <p className="text-xs text-muted mt-2">
                    Select a date and time at least 24 hours in the future
                  </p>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <FileText className="w-4 h-4 inline mr-2" />
                    Service Notes
                  </label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Describe the service you need (e.g., 'Inspect roof for leaks')"
                    className="input-base w-full h-24 resize-none"
                  />
                </div>

                {/* Special Requests */}
                <div>
                  <label className="block text-sm font-semibold mb-3">Special Requests</label>
                  <textarea
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="Any special instructions for the service provider"
                    className="input-base w-full h-20 resize-none"
                  />
                </div>

                {/* Price Summary */}
                <Card className="p-4 bg-accent/5 border-accent/20">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Total Cost</span>
                    <span className="text-2xl font-bold text-accent">
                      ${service?.basePrice || 0}
                    </span>
                  </div>
                  <p className="text-xs text-muted mt-2">Payment will be collected after confirmation</p>
                </Card>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isSubmitting || !selectedProperty || !scheduledDate}
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Creating Order..." : "Request Service"}
                </Button>

                <Button
                  type="button"
                  onClick={() => navigate("/services")}
                  variant="outline"
                  className="w-full border-2 border-accent text-accent hover:bg-accent/10"
                >
                  Cancel
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
