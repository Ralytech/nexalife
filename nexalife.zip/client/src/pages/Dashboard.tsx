import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Plus, Home, Package, FileText, CreditCard, Bell, Settings, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Dashboard() {
  const { user, logout, loading } = useAuth();
  const [, navigate] = useLocation();

  const { data: properties, isLoading: propertiesLoading } = trpc.properties.list.useQuery(undefined, {
    enabled: !!user,
  });

  const { data: orders, isLoading: ordersLoading } = trpc.orders.list.useQuery(undefined, {
    enabled: !!user,
  });

  const { data: notifications } = trpc.notifications.list.useQuery(
    { unreadOnly: true },
    { enabled: !!user }
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">N</span>
            </div>
            <div>
              <p className="font-semibold">{user.name}</p>
              <p className="text-xs text-muted capitalize">{user.role}</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="relative p-2 hover:bg-muted/20 rounded-lg transition-colors">
              <Bell className="w-5 h-5 text-muted" />
              {notifications && notifications.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
              )}
            </button>

            <button
              onClick={() => navigate("/settings")}
              className="p-2 hover:bg-muted/20 rounded-lg transition-colors"
            >
              <Settings className="w-5 h-5 text-muted" />
            </button>

            <button onClick={handleLogout} className="p-2 hover:bg-muted/20 rounded-lg transition-colors">
              <LogOut className="w-5 h-5 text-muted" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {user.name}!</h1>
          <p className="text-muted">Manage your properties and services in Haiti</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted mb-1">Properties</p>
                <p className="text-3xl font-bold">{properties?.length || 0}</p>
              </div>
              <Home className="w-10 h-10 text-accent/20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted mb-1">Active Orders</p>
                <p className="text-3xl font-bold">
                  {orders?.filter((o) => o.status !== "completed").length || 0}
                </p>
              </div>
              <Package className="w-10 h-10 text-accent/20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted mb-1">Completed</p>
                <p className="text-3xl font-bold">
                  {orders?.filter((o) => o.status === "completed").length || 0}
                </p>
              </div>
              <FileText className="w-10 h-10 text-accent/20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted mb-1">Total Spent</p>
                <p className="text-3xl font-bold">$0</p>
              </div>
              <CreditCard className="w-10 h-10 text-accent/20" />
            </div>
          </Card>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Properties Section */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Your Properties</h2>
              <Button
                onClick={() => navigate("/properties/new")}
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Property
              </Button>
            </div>

            {propertiesLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="p-4 animate-pulse">
                    <div className="h-24 bg-muted/20 rounded"></div>
                  </Card>
                ))}
              </div>
            ) : properties && properties.length > 0 ? (
              <div className="space-y-4">
                {properties.map((property) => (
                  <Card
                    key={property.id}
                    className="p-6 hover:shadow-elevated transition-shadow cursor-pointer"
                    onClick={() => navigate(`/properties/${property.id}`)}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-semibold mb-1">{property.name}</h3>
                        <p className="text-sm text-muted mb-2">
                          {property.address}, {property.city}
                        </p>
                        <div className="flex gap-2">
                          <span className="badge badge-primary text-xs capitalize">{property.type}</span>
                          <span className="badge badge-success text-xs">{property.status}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted">Added</p>
                        <p className="text-sm font-medium">
                          {new Date(property.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <Home className="w-12 h-12 text-muted/30 mx-auto mb-4" />
                <p className="text-muted mb-4">No properties yet</p>
                <Button
                  onClick={() => navigate("/properties/new")}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  Add Your First Property
                </Button>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button
                  onClick={() => navigate("/services")}
                  variant="outline"
                  className="w-full justify-start border-2 border-accent text-accent hover:bg-accent/10"
                >
                  <Package className="w-4 h-4 mr-2" />
                  Request Service
                </Button>
                <Button
                  onClick={() => navigate("/grocery")}
                  variant="outline"
                  className="w-full justify-start border-2 border-accent text-accent hover:bg-accent/10"
                >
                  <Package className="w-4 h-4 mr-2" />
                  Send Groceries
                </Button>
                <Button
                  onClick={() => navigate("/orders")}
                  variant="outline"
                  className="w-full justify-start border-2 border-accent text-accent hover:bg-accent/10"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  View Orders
                </Button>
              </div>
            </Card>

            {/* Recent Notifications */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Recent Notifications</h3>
              {notifications && notifications.length > 0 ? (
                <div className="space-y-3">
                  {notifications.slice(0, 5).map((notif) => (
                    <div key={notif.id} className="pb-3 border-b border-border last:border-0">
                      <p className="text-sm font-medium">{notif.title}</p>
                      <p className="text-xs text-muted mt-1">{notif.message}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted">No new notifications</p>
              )}
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
