import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Home as HomeIcon, Package, MapPin, FileText, Users, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function HomePage() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-background/95 flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/95">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">N</span>
            </div>
            <span className="font-bold text-xl gradient-text">NexaLife</span>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted">Welcome, {user?.name}</span>
                <Button
                  onClick={() => navigate("/dashboard")}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  Dashboard
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                  Sign In
                </Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                Manage Your Haiti Properties
                <span className="gradient-text"> Effortlessly</span>
              </h1>
              <p className="text-xl text-muted leading-relaxed">
                Connect with trusted service providers to inspect, maintain, and manage your properties in Haiti from anywhere in the world.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              {!isAuthenticated && (
                <>
                  <a href={getLoginUrl()}>
                    <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 w-full sm:w-auto">
                      Get Started <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </a>
                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full sm:w-auto border-2 border-accent text-accent hover:bg-accent/10"
                  >
                    Learn More
                  </Button>
                </>
              )}
            </div>

            <div className="flex gap-8 pt-8 border-t border-border">
              <div>
                <p className="text-2xl font-bold">500+</p>
                <p className="text-sm text-muted">Properties Managed</p>
              </div>
              <div>
                <p className="text-2xl font-bold">1000+</p>
                <p className="text-sm text-muted">Services Completed</p>
              </div>
              <div>
                <p className="text-2xl font-bold">98%</p>
                <p className="text-sm text-muted">Satisfaction Rate</p>
              </div>
            </div>
          </div>

          <div className="relative h-96 md:h-full">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-transparent rounded-2xl blur-3xl"></div>
            <div className="relative bg-card rounded-2xl p-8 shadow-elegant border border-border">
              <div className="space-y-4">
                <div className="h-48 bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-muted/20 rounded w-3/4"></div>
                  <div className="h-4 bg-muted/20 rounded w-1/2"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Everything you need to manage your properties and connect with service providers
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: HomeIcon,
                title: "Property Management",
                description: "Register and manage multiple properties with photos and detailed information",
              },
              {
                icon: Zap,
                title: "Service Ordering",
                description: "Request inspections, maintenance, cleaning, and repairs with real-time tracking",
              },
              {
                icon: FileText,
                title: "Photo Reports",
                description: "Receive detailed photo reports with timestamps and inspection checklists",
              },
              {
                icon: MapPin,
                title: "Location Tracking",
                description: "Interactive maps showing your properties and service provider locations",
              },
              {
                icon: Package,
                title: "Grocery Delivery",
                description: "Send groceries to family with predefined baskets and custom items",
              },
              {
                icon: Users,
                title: "Provider Network",
                description: "Access verified service providers with ratings and specializations",
              },
            ].map((feature, idx) => {
              const IconComponent = feature.icon;
              return (
                <Card key={idx} className="p-6 hover:shadow-elevated transition-shadow">
                  <IconComponent className="w-12 h-12 text-accent mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted">{feature.description}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Comprehensive solutions for managing your Haiti properties
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "NexaInspect", desc: "Property inspection", icon: "🔍" },
              { name: "NexaMarket", desc: "Grocery delivery", icon: "🛒" },
              { name: "NexaCare", desc: "Home maintenance", icon: "🔧" },
              { name: "NexaVerify", desc: "Pre-purchase inspection", icon: "✓" },
            ].map((service, idx) => (
              <Card key={idx} className="p-6 text-center hover:shadow-elevated transition-shadow">
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{service.name}</h3>
                <p className="text-sm text-muted">{service.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-accent/10 to-accent/5 rounded-2xl mx-4 md:mx-0 md:rounded-3xl">
        <div className="container text-center space-y-8">
          <div>
            <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-lg text-muted max-w-2xl mx-auto">
              Join hundreds of diaspora property owners managing their Haiti properties with confidence
            </p>
          </div>

          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Sign Up Now <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 mt-20">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">NexaLife</h3>
              <p className="text-sm text-muted">Managing Haiti properties for diaspora communities</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted">
                <li><a href="#" className="hover:text-accent">Features</a></li>
                <li><a href="#" className="hover:text-accent">Pricing</a></li>
                <li><a href="#" className="hover:text-accent">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted">
                <li><a href="#" className="hover:text-accent">About</a></li>
                <li><a href="#" className="hover:text-accent">Blog</a></li>
                <li><a href="#" className="hover:text-accent">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted">
                <li><a href="#" className="hover:text-accent">Privacy</a></li>
                <li><a href="#" className="hover:text-accent">Terms</a></li>
                <li><a href="#" className="hover:text-accent">Cookies</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-muted">
            <p>&copy; 2024 NexaLife. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-accent">Twitter</a>
              <a href="#" className="hover:text-accent">LinkedIn</a>
              <a href="#" className="hover:text-accent">Facebook</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
