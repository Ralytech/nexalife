import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Upload, MapPin, Home, FileText, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function AddProperty() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();

  const [formData, setFormData] = useState({
    name: "",
    type: "house" as const,
    address: "",
    city: "",
    description: "",
    photos: [] as string[],
  });

  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const [photoInput, setPhotoInput] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createPropertyMutation = trpc.properties.create.useMutation({
    onSuccess: () => {
      toast.success("Property added successfully!");
      navigate("/dashboard");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to add property");
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAddPhotoUrl = () => {
    if (!photoInput.trim()) {
      toast.error("Please enter a photo URL");
      return;
    }

    if (!photoInput.startsWith("http")) {
      toast.error("Please enter a valid URL starting with http:// or https://");
      return;
    }

    setPhotoUrls((prev) => [...prev, photoInput]);
    setPhotoInput("");
    toast.success("Photo URL added");
  };

  const handleRemovePhoto = (index: number) => {
    setPhotoUrls((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Property name is required");
      return;
    }

    if (!formData.address.trim()) {
      toast.error("Address is required");
      return;
    }

    if (!formData.city.trim()) {
      toast.error("City is required");
      return;
    }

    setIsSubmitting(true);

    try {
      await createPropertyMutation.mutateAsync({
        name: formData.name,
        type: formData.type,
        address: formData.address,
        city: formData.city,
        description: formData.description,
        photos: photoUrls,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const propertyTypes = [
    { value: "house", label: "House" },
    { value: "apartment", label: "Apartment" },
    { value: "car", label: "Car" },
    { value: "land", label: "Land" },
    { value: "commercial", label: "Commercial" },
  ];

  const haitianCities = [
    "Port-au-Prince",
    "Cap-Haïtien",
    "Gonaïves",
    "Les Cayes",
    "Fort-Liberté",
    "Jérémie",
    "Jacmel",
    "Hinche",
    "Petit-Goâve",
    "Mirebalais",
    "Other",
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container flex items-center gap-4 py-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-muted/20 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-muted" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Add Property</h1>
            <p className="text-sm text-muted">Register a new property in Haiti</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2">
            <Card className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Property Name */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <Home className="w-4 h-4 inline mr-2" />
                    Property Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="e.g., Beach House, Mountain Villa"
                    className="input-base w-full"
                    required
                  />
                  <p className="text-xs text-muted mt-2">Give your property a memorable name</p>
                </div>

                {/* Property Type */}
                <div>
                  <label className="block text-sm font-semibold mb-3">Property Type *</label>
                  <select
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    className="input-base w-full"
                    required
                  >
                    {propertyTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Address */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    Street Address *
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    placeholder="e.g., 123 Main Street"
                    className="input-base w-full"
                    required
                  />
                </div>

                {/* City */}
                <div>
                  <label className="block text-sm font-semibold mb-3">City *</label>
                  <select
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="input-base w-full"
                    required
                  >
                    <option value="">Select a city</option>
                    {haitianCities.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <FileText className="w-4 h-4 inline mr-2" />
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Describe your property (bedrooms, amenities, condition, etc.)"
                    className="input-base w-full h-24 resize-none"
                  />
                  <p className="text-xs text-muted mt-2">Help service providers understand your property</p>
                </div>

                {/* Photo URLs */}
                <div>
                  <label className="block text-sm font-semibold mb-3">
                    <Upload className="w-4 h-4 inline mr-2" />
                    Property Photos
                  </label>
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <input
                        type="url"
                        value={photoInput}
                        onChange={(e) => setPhotoInput(e.target.value)}
                        placeholder="https://example.com/photo.jpg"
                        className="input-base flex-1"
                        onKeyPress={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleAddPhotoUrl();
                          }
                        }}
                      />
                      <Button
                        type="button"
                        onClick={handleAddPhotoUrl}
                        className="bg-accent text-accent-foreground hover:bg-accent/90"
                      >
                        Add Photo
                      </Button>
                    </div>
                    <p className="text-xs text-muted">
                      Paste image URLs from your cloud storage (Google Drive, Dropbox, etc.)
                    </p>

                    {/* Photo Preview */}
                    {photoUrls.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Added Photos ({photoUrls.length})</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {photoUrls.map((url, index) => (
                            <div key={index} className="relative group">
                              <div className="aspect-square rounded-lg overflow-hidden bg-muted/20 border border-border">
                                <img
                                  src={url}
                                  alt={`Property photo ${index + 1}`}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).src =
                                      "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect fill='%23f0f0f0' width='100' height='100'/%3E%3Ctext x='50' y='50' text-anchor='middle' dy='.3em' fill='%23999' font-size='12'%3EImage Error%3C/text%3E%3C/svg%3E";
                                  }}
                                />
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemovePhoto(index)}
                                className="absolute top-1 right-1 bg-destructive text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                ✕
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? "Adding Property..." : "Add Property"}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => navigate("/dashboard")}
                    variant="outline"
                    className="flex-1 border-2 border-accent text-accent hover:bg-accent/10"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          </div>

          {/* Info Sidebar */}
          <div className="space-y-6">
            {/* Tips Card */}
            <Card className="p-6 bg-accent/5 border-accent/20">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-accent" />
                Tips for Success
              </h3>
              <ul className="space-y-3 text-sm text-foreground">
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Use a clear, descriptive property name</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Include complete address details</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Add multiple photos for better visibility</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Describe any special features or concerns</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span>Service providers use this info to prepare</span>
                </li>
              </ul>
            </Card>

            {/* Supported Cities */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Supported Cities</h3>
              <p className="text-sm text-muted mb-3">We currently serve properties in these Haitian cities:</p>
              <div className="flex flex-wrap gap-2">
                {haitianCities.slice(0, 5).map((city) => (
                  <span key={city} className="badge badge-primary text-xs">
                    {city}
                  </span>
                ))}
                <span className="badge badge-primary text-xs">+{haitianCities.length - 5} more</span>
              </div>
            </Card>

            {/* Property Requirements */}
            <Card className="p-6">
              <h3 className="font-semibold mb-4">What We Need</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <span className="text-accent font-bold">✓</span>
                  <span>Property name and type</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-accent font-bold">✓</span>
                  <span>Complete address</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-accent font-bold">✓</span>
                  <span>City location</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-muted">Description (optional)</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-accent font-bold">•</span>
                  <span className="text-muted">Photos (optional)</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
