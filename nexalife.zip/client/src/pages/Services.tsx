import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Search, Filter, Zap, CheckCircle2, MapPin, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export default function Services() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: services, isLoading } = trpc.services.list.useQuery();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-12 w-48 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user) {
    navigate("/");
    return null;
  }

  const categories = ["inspection", "maintenance", "cleaning", "repairs", "grocery"];

  const filteredServices = services?.filter((service) => {
    const matchesCategory = !selectedCategory || service.category === selectedCategory;
    const matchesSearch =
      !searchTerm ||
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const serviceIcons: Record<string, string> = {
    inspection: "🔍",
    maintenance: "🔧",
    cleaning: "🧹",
    repairs: "🛠️",
    grocery: "🛒",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="p-2 hover:bg-muted/20 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-muted" />
            </button>
            <div>
              <h1 className="text-2xl font-bold">Services</h1>
              <p className="text-sm text-muted">Browse and request services for your properties</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Search and Filter Section */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted" />
            <input
              type="text"
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-base pl-12 w-full"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                selectedCategory === null
                  ? "bg-accent text-accent-foreground"
                  : "bg-muted/20 text-foreground hover:bg-muted/30"
              }`}
            >
              All Services
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap capitalize ${
                  selectedCategory === category
                    ? "bg-accent text-accent-foreground"
                    : "bg-muted/20 text-foreground hover:bg-muted/30"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Services Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-24 bg-muted/20 rounded mb-4"></div>
                <div className="h-4 bg-muted/20 rounded mb-2"></div>
                <div className="h-4 bg-muted/20 rounded w-2/3"></div>
              </Card>
            ))}
          </div>
        ) : filteredServices && filteredServices.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => (
              <Card
                key={service.id}
                className="p-6 hover:shadow-elevated transition-all cursor-pointer group"
                onClick={() => navigate(`/services/${service.id}`)}
              >
                {/* Icon and Badge */}
                <div className="flex items-start justify-between mb-4">
                  <div className="text-4xl">{serviceIcons[service.category] || "⚙️"}</div>
                  <span className="badge badge-primary text-xs capitalize">{service.category}</span>
                </div>

                {/* Title and Description */}
                <h3 className="text-lg font-semibold mb-2 group-hover:text-accent transition-colors">
                  {service.name}
                </h3>
                <p className="text-sm text-muted mb-4 line-clamp-2">{service.description}</p>

                {/* Details */}
                <div className="space-y-2 mb-4 text-sm">
                  {service.basePrice && (
                    <div className="flex items-center gap-2 text-foreground">
                      <Zap className="w-4 h-4 text-accent" />
                      <span className="font-semibold">${service.basePrice}</span>
                    </div>
                  )}
                  {service.estimatedDuration && (
                    <div className="flex items-center gap-2 text-muted">
                      <Clock className="w-4 h-4" />
                      <span>{Math.round(service.estimatedDuration / 60)} hours</span>
                    </div>
                  )}
                </div>

                {/* CTA Button */}
                <Button
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/services/${service.id}`);
                  }}
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  Select Service
                </Button>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Filter className="w-12 h-12 text-muted/30 mx-auto mb-4" />
            <p className="text-muted mb-4">No services found matching your criteria</p>
            <Button
              onClick={() => {
                setSearchTerm("");
                setSelectedCategory(null);
              }}
              variant="outline"
              className="border-2 border-accent text-accent hover:bg-accent/10"
            >
              Clear Filters
            </Button>
          </Card>
        )}
      </main>
    </div>
  );
}
